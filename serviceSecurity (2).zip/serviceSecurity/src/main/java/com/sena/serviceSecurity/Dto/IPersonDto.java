package com.sena.serviceSecurity.Dto;

public interface IPersonDto {
	
	String getPerson();
	
	String getDocument_type();
	
	String getCode();
	
	String getDocument();
	
	String getFirstName();
	
	String getLastName();
	
	Long getPerson_Id();

}
