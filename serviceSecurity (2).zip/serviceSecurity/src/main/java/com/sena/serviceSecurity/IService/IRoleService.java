package com.sena.serviceSecurity.IService;

public interface IRoleService {

}
