package com.sena.serviceSecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.serviceSecurity.Dto.IDepartamentDto;
import com.sena.serviceSecurity.Entity.Departament;

@Repository
public interface IDepartamentRepository extends IBaseRepository<Departament, Long> {

	@Query(value = "SELECT " +
	        "    `department`.`name` AS name_departament, " +
	        "    `department`.`code` AS code_departament, " +
	        "    `c`.`name` AS country " +
	        "FROM " +
	        "    `service_security`.`departament` " +
	        "INNER JOIN " +
	        "    `country` AS c ON `departament`.`country_id` = `c`.`id`", nativeQuery = true)
	List<IDepartamentDto> getListDepartament();

}
