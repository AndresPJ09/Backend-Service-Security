package com.sena.serviceSecurity.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.serviceSecurity.Dto.ICountryDto;
import com.sena.serviceSecurity.Entity.Country;
import com.sena.serviceSecurity.IRepository.IBaseRepository;
import com.sena.serviceSecurity.IRepository.ICountryRepository;
import com.sena.serviceSecurity.IService.ICountryService;

@Service
public class CountryService extends ABaseService<Country> implements ICountryService {

	@Autowired
	public ICountryRepository repository;

	@Override
	protected IBaseRepository<Country, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	@Override
	public List<ICountryDto> getListCountry() {
		// TODO Auto-generated method stub
		return repository.getListCountry();
	}
	
	@Override
	public void delete(Long id){
		repository.deleteById(id);
	}

}