package com.sena.serviceSecurity.IService;

import java.util.List;

import com.sena.serviceSecurity.Dto.IPersonDto;
import com.sena.serviceSecurity.Entity.Person;

public interface IPersonService extends IBaseService<Person>{
	
	List<IPersonDto> getListPerson();
	
}
