package com.sena.serviceSecurity.IService;

public interface IModuleService {

}
