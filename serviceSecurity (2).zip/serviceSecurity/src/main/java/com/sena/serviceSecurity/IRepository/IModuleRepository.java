package com.sena.serviceSecurity.IRepository;

import org.springframework.stereotype.Repository;
import com.sena.serviceSecurity.Entity.Module;


@Repository
public interface IModuleRepository extends IBaseRepository<Module, Long>{

}
