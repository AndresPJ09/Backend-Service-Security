package com.sena.serviceSecurity.Dto;

import java.util.List;

public interface IModuleDto extends IGnericDto{
	
	String Module();
	
	String getDescripcion();
	
	String getViewName();
	
	String getViewRoute();
	
	List<IViewDto> getViews();
	
	void setViews(List<IViewDto> views);

}
