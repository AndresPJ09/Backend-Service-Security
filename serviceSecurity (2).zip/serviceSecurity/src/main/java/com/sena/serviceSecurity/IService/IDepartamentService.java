package com.sena.serviceSecurity.IService;

import java.util.List;

import com.sena.serviceSecurity.Dto.IDepartamentDto;
import com.sena.serviceSecurity.Entity.Departament;

public interface IDepartamentService extends IBaseService<Departament>{
	
	List<IDepartamentDto> getListDepartament();

}
