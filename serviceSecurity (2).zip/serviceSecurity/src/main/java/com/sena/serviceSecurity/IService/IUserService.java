package com.sena.serviceSecurity.IService;

public interface IUserService {

}
