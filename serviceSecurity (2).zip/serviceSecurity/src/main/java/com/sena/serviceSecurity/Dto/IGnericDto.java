package com.sena.serviceSecurity.Dto;

public interface IGnericDto {
	
	Long getId();

	Boolean getState();
}
