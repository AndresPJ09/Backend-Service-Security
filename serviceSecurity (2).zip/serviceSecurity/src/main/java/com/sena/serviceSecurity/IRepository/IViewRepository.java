package com.sena.serviceSecurity.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.serviceSecurity.Entity.View;

@Repository
public interface IViewRepository extends IBaseRepository<View, Long>{

}
