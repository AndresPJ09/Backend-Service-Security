package com.sena.serviceSecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.serviceSecurity.Dto.ICityDto;
import com.sena.serviceSecurity.Entity.City;

@Repository
public interface ICityRepository extends IBaseRepository<City, Long> {
	
	@Query(value = "SELECT " +
	        "    city.id, " +
	        "    city.code AS city_code, " +
	        "    city.name AS city_name, " +
	        "    d.name AS department " +
	        "FROM " +
	        "    service_Security.city " +
	        "LEFT JOIN " +
	        "    department AS d ON city.department_id = d.id", nativeQuery = true)
	List<ICityDto> getListCity();
}
