package com.sena.serviceSecurity.Controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.serviceSecurity.Entity.Departament;
import com.sena.serviceSecurity.IService.IDepartamentService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/departament")
public class DepartamentController extends ABaseController<Departament, IDepartamentService>{
	public DepartamentController(IDepartamentService service) {
		super(service, "Departament");
		
		
	}

}
