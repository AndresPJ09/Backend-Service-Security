package com.sena.serviceSecurity.Dto;

import java.util.List;

public interface IUserDto extends IGnericDto{
	
	String getUsername();
	
	String getPersonName();
	
	String getPersonEmail();
	
	Long getRoleId();
	
	List<IModuleDto> getModules();
	
	void setModuler(List<IModuleDto> modules);

}
