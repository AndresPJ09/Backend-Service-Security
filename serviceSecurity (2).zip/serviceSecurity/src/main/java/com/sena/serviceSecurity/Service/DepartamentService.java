package com.sena.serviceSecurity.Service;

public class DepartamentService {

}
