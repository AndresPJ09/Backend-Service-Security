package com.sena.serviceSecurity.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.serviceSecurity.Entity.Role;

@Repository
public interface IRoleRepository extends IBaseRepository<Role, Long>{

}
