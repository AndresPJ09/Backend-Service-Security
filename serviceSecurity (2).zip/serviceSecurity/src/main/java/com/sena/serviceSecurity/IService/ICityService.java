package com.sena.serviceSecurity.IService;

import java.util.List;

import com.sena.serviceSecurity.Dto.ICityDto;
import com.sena.serviceSecurity.Entity.City;

public interface ICityService extends IBaseService<City>{
	
	List<ICityDto> getListCity();

}
