package com.sena.serviceSecurity.Dto;


public interface ICityDto extends IGnericDto{
	
	String getName_city();
	
	String getCode_city();
	
	String getDepartament();

}
