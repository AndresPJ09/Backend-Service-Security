package com.sena.serviceSecurity.Dto;

public interface IRoleDto extends IGnericDto{
	
	String getRole();
	
	String getDescripcion();
	

}
