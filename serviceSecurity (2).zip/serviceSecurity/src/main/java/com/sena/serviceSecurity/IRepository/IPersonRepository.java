package com.sena.serviceSecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.serviceSecurity.Dto.IPersonDto;
import com.sena.serviceSecurity.Entity.Person;

@Repository
public interface IPersonRepository extends IBaseRepository<Person, Long>{
	
	@Query(value = " SELECT  " + " id, " + " concat(first_name,'  ',last_name) as person " + "	FROM  " + "	person "
			+ "	WHERE  " + " deleted_at IS NULL", nativeQuery = true)
	List<IPersonDto> getListPerson();
}
