package com.sena.serviceSecurity.Service;

import org.hibernate.annotations.SecondaryRow;
import org.springframework.context.annotation.Lazy;

import com.sena.serviceSecurity.Entity.Person;
import com.sena.serviceSecurity.IRepository.IBaseRepository;
import com.sena.serviceSecurity.IRepository.IPersonRepository;

@SecondaryRow
public class PersonService extends ABaseService<Person>{
	
	/*private final IPersonRepository repository;
	@Lazy
    private final ICustomerService serviceCustomer;

    public PersonService(IPersonRepository repository, @Lazy ICustomerService serviceCustomer) {
        this.repository = repository;
        this.serviceCustomer = serviceCustomer;
    }

	@Override
	protected IBaseRepository<Person, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository.getListPerson();
	}

*/}
