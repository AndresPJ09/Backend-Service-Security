package com.sena.serviceSecurity.IService;

import java.util.List;

import com.sena.serviceSecurity.Dto.ICountryDto;
import com.sena.serviceSecurity.Entity.Country;

public interface ICountryService extends IBaseService<Country>{
	
	List<ICountryDto> getListCountry();

}
