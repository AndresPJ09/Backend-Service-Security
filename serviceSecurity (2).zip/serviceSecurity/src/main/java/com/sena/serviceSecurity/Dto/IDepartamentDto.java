package com.sena.serviceSecurity.Dto;

public interface IDepartamentDto extends IGnericDto{
	
	String getCode_departament();
	
	String getName_departament();
	
	String getCountry();

}
