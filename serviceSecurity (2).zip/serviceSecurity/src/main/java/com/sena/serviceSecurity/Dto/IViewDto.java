package com.sena.serviceSecurity.Dto;

public interface IViewDto extends IGnericDto{
	
	String getModule();
	
	String getName();
	
	String getRoute();
	
	String getDescripcion();

}
