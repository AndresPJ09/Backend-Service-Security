package com.sena.serviceSecurity.Dto;

public interface ICountryDto extends IGnericDto{
	
	String getName_country();

	String getCode_country();

}
