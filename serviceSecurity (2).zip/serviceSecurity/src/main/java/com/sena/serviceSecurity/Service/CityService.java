package com.sena.serviceSecurity.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sena.serviceSecurity.Dto.ICityDto;
import com.sena.serviceSecurity.Entity.City;
import com.sena.serviceSecurity.IRepository.IBaseRepository;
import com.sena.serviceSecurity.IRepository.ICityRepository;
import com.sena.serviceSecurity.IService.ICityService;

public class CityService extends ABaseService<City> implements ICityService {

	@Override
	protected IBaseRepository<City, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	@Autowired
	public ICityRepository repository;

	@Override
	public List<ICityDto> getListCity() {
		// TODO Auto-generated method stub
		return repository.getListCity();
	}
	
	@Override
	public void delete(Long id){
		repository.deleteById(id);
	}

}
